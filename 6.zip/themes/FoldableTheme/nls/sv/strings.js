define({
  "_themeLabel": "Vikbart tema",
  "_layout_default": "Standardlayout",
  "_layout_layout1": "Layout 1"
});